﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApp1.ViewModel;

namespace WpfApp1.Model
{
    class Group
    {
        public int Id { get; set; }
        public int IdSpeciality { get; set; }
        public int IdQualification { get; set; }
        public int IdFormEducation { get; set; }
        public string Faculty { get; set; }
        public string Name { get; set; }
		public int Course { get; set; }
		public int CountStudent { get; set; }
		public int CountSubGroup { get; set; }
		public Group() { }
        public Group(int id, int idSpeciality, int idQualification, int idFormEducation, string faculty, string name, int course, int countStudent, int countSubGroup)
        {
            this.Id = id;
            this.IdSpeciality = idSpeciality;
            this.IdQualification = idQualification;
            this.IdFormEducation = idFormEducation;
			this.Faculty = faculty;
			this.Name = name;
			this.Course = course;
			this.CountStudent = countStudent;
			this.CountSubGroup = countSubGroup;

		}
        public Group ShallowCopy()
        {
            return (Group)this.MemberwiseClone();
        }
        public Group CopyFromGroupDPO(GroupDPO g)
        {
            FormEducationViewModel vmFormEducation = new FormEducationViewModel();
            int formId = 0;
            foreach (var f in vmFormEducation.ListFormEducation)
            {
                if (f.NameForm == g.FormEducation)
                {
                    formId = f.Id;
                    break;
                }
            }

            QualificationViewModel vmQualification = new QualificationViewModel();
            int qualificationId = 0;
            foreach (var q in vmQualification.ListQualification)
            {
                if (q.NameQualification == g.Qualification)
                {
					qualificationId = q.Id;
                    break;
                }
            }
                SpecialityViewModel vmSpeciality = new SpecialityViewModel();
                int specialityId = 0;
                foreach (var s in vmSpeciality.ListSpeciality)
                {
                    if (s.NameSpeciality == g.Speciality)
                    {
					    specialityId = s.Id;
                        break;
                    }
                }
                if (specialityId != 0 & qualificationId != 0 & formId != 0)
                {
                    this.Id = g.Id;
                    this.IdSpeciality = specialityId;
                    this.IdQualification = qualificationId;
                    this.IdFormEducation = formId;
                    this.Faculty = g.Faculty;
                    this.Course = g.Course;
                    this.Name = g.Name;
                    this.CountStudent = g.CountStudent;
                    this.CountSubGroup = g.CountSubGroup;
                }
                return this;
            }

        }

    }