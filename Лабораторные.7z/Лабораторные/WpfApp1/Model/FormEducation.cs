﻿    using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1.Model
{
    class FormEducation
    {
        public int Id { get; set; }
        public string NameForm { get; set; }


		public FormEducation() { }
        public FormEducation(int id, string nameForm)
        { 
            this.Id = id;
            this.NameForm = nameForm;
            
        }
        public FormEducation ShallowCopy()
        {
            return (FormEducation)this.MemberwiseClone();
        }

    }
}
