﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApp1.Model;
using WpfApp1.ViewModel;

namespace WpfApp1
{
    class GroupDPO
    {
        public int Id { get; set; }
		public string Speciality { get; set; }
        public string Qualification { get; set; }
        public string FormEducation { get; set; }
        public string Faculty { get; set; }
        public string Name { get; set; }
		public int Course { get; set; }
		public int CountStudent { get; set; }
		public int CountSubGroup { get; set; }
		public GroupDPO() { }
        public GroupDPO(int id, string spec, string qual, string form, string fac, string name, int cource, int countstud, int countsubgr)
        {
            this.Id = id;
            this.Speciality = spec;
            this.Qualification = qual;
            this.FormEducation = form;
            this.Faculty = fac;
            this.Name = name;
            this.Course = cource;
            this.CountStudent = countstud;
            this.CountSubGroup = countsubgr;
        }
        public GroupDPO ShallowCopy()
        {
            return (GroupDPO)this.MemberwiseClone();
        }
        public GroupDPO CopyFromAccount(Group group)
        {
            GroupDPO grDPO = new GroupDPO();

            FormEducationViewModel vmFormEducation = new FormEducationViewModel();
            string formed = string.Empty;
            foreach (var fe in vmFormEducation.ListFormEducation)
            {
                if (fe.Id == group.IdFormEducation)
                {
                    formed = fe.NameForm;
                    break;
                }
            }

            QualificationViewModel vmQualification = new QualificationViewModel();
            string qualification = string.Empty;
            foreach (var agr in vmQualification.ListQualification)
            {
                if (agr.Id == group.IdQualification)
                {
					qualification = agr.NameQualification;
                    break;
                }
            }

            SpecialityViewModel vmSpeciality = new SpecialityViewModel();
            string speciality = string.Empty;
            foreach (var ta in vmSpeciality.ListSpeciality)
            {
                if (ta.Id == group.IdSpeciality)
                {
                    speciality = ta.NameSpeciality;
                    break;
                }
            }

            if (speciality != string.Empty & qualification != string.Empty & formed != string.Empty)
            {
				grDPO.Id = group.Id;
				grDPO.Speciality = speciality;
				grDPO.Qualification = qualification;
				grDPO.FormEducation = formed;
                grDPO.Faculty = group.Faculty;
                grDPO.Course = group.Course;
                grDPO.Name = group.Name;
                grDPO.CountSubGroup = group.CountSubGroup;
                grDPO.CountStudent = group.CountStudent;
            }
            return grDPO;
        }

    }

}
