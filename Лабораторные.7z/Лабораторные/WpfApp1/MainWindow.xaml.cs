﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp1.View;
using WpfApp1.ViewModel;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        internal static GroupViewModel vmGroup;

        public MainWindow()
        {
            InitializeComponent();
        }
        public static int IdGroup { get; set; }
        private void Group_OnClick(object sender, RoutedEventArgs e)
        {
            WindowGroup wGroup = new WindowGroup();
            wGroup.Show();
        }
        private void Speciality_OnClick(object sender, RoutedEventArgs e)
        {
            WindowSpeciality wSpeciality = new WindowSpeciality();
			wSpeciality.Show();
        }
        private void FormEducation_OnClick(object sender, RoutedEventArgs e)
        {
            WindowFormEducation wFormEducation = new WindowFormEducation();
			wFormEducation.Show();
        }
        private void Qualification_OnClick(object sender, RoutedEventArgs e)
        {
            WindowQualification wQualification = new WindowQualification();
			wQualification.Show();
        }
    }
    }