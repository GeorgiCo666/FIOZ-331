﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApp1.Model;

namespace WpfApp1.Helper
{
    class FindSpeciality
	{
        int id;
        public FindSpeciality(int id)
        {
            this.id = id;
        }
        public bool SpecialityPredicate(Speciality speciality)
        {
            return speciality.Id == id;
        }
    }
}
