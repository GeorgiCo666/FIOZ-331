﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApp1.Model;

namespace WpfApp1.ViewModel
{
    class SpecialityViewModel
    {
        public int MaxId()
        {
            int max = 0;
            foreach (var b in this.ListSpeciality)
            {
                if (max < b.Id)
                {
                    max = b.Id;
                };
            }
            return max;
        }
        public ObservableCollection<Speciality> ListSpeciality { get; set; } = new ObservableCollection<Speciality>();
        public SpecialityViewModel()
        {
            this.ListSpeciality.Add(
            new Speciality
            {
                Id = 1,
                NameSpeciality = "Программист"
            });
            this.ListSpeciality.Add(
            new Speciality
            {
                Id = 2,
				NameSpeciality = "Экономист"
			});
            this.ListSpeciality.Add(
            new Speciality
            {
                Id = 3,
				NameSpeciality = "Юрист"
			});
        }
    }
}