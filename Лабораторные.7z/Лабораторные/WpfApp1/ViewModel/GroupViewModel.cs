﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Xml.Linq;
using WpfApp1.Model;

namespace WpfApp1.ViewModel
{
    class GroupViewModel
    {
        public ObservableCollection<Group> ListGroup { get; set; } = new ObservableCollection<Group>();
        public GroupViewModel()
        {
            this.ListGroup.Add(
            new Group
            {

                Id = 1,
                IdSpeciality = 1,
                IdQualification = 1,
                IdFormEducation = 1,
                Faculty = "КТиИБ",
                Name = "ФИОЗ-331",
                Course = 3,
                CountStudent = 15,
                CountSubGroup = 2,
        
		});
            
        }
        public int MaxId()
        {
            int max = 0;
            foreach (var a in this.ListGroup)
            {
                if (max < a.Id)
                {
                    max = a.Id;
                };
            }
            return max;
        }
    }
}