﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApp1.Model;

namespace WpfApp1.ViewModel
{
    class FormEducationViewModel
    {
        public int MaxId()
        {
            int max = 0;
            foreach (var b in this.ListFormEducation)
            {
                if (max < b.Id)
                {
                    max = b.Id;
                };
            }
            return max;
        }
        public ObservableCollection<FormEducation> ListFormEducation { get; set; } = new ObservableCollection<FormEducation>();
        public FormEducationViewModel()
        {
            this.ListFormEducation.Add(
            new FormEducation
            {
                Id = 1,
                NameForm = "Очная",
                
            });
            this.ListFormEducation.Add(
            new FormEducation
			{
                Id = 2,
				NameForm = "Заочная",
                
            });
            this.ListFormEducation.Add(
            new FormEducation
			{
                Id = 3,
				NameForm = "Очно-Заочная",
                
            });
        }
    }
}