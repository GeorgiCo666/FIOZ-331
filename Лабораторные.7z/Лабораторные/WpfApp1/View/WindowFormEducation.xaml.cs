﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfApp1.Model;
using WpfApp1.ViewModel;
using WpfApp1.View;

namespace WpfApp1.View
{
    /// <summary>
    /// Логика взаимодействия для WindowFormEducation.xaml
    /// </summary>
    public partial class WindowFormEducation : Window
    {
		FormEducationViewModel vmFormEducation = new FormEducationViewModel();
		public WindowFormEducation()
        {
            InitializeComponent();
            FormEducationViewModel vmFormEducation = new FormEducationViewModel();
			lvFormEducation.ItemsSource = vmFormEducation.ListFormEducation;
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            FormEducationViewModel vmFormEducation = new FormEducationViewModel();
			WindowNewFormEducation wnFormEducation = new WindowNewFormEducation
			{
                Title = "Данные о новой форме обучения",
                Owner = this
            };
            // формирование кода новой формы обучения
            int maxIdFormEducation = vmFormEducation.MaxId() + 1;
			FormEducation formEducation = new FormEducation
			{
                Id = maxIdFormEducation
			};
			wnFormEducation.DataContext = formEducation;
            if (wnFormEducation.ShowDialog() == true)
            {
				vmFormEducation.ListFormEducation.Add(formEducation);
            }
        }
        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {   
			WindowNewFormEducation wnFormEducation = new WindowNewFormEducation
			{
                Title = "Редактирование формы обучения",
                Owner = this
            };
			FormEducation formEducation = lvFormEducation.SelectedItem as FormEducation;
            if (formEducation != null)
            {
				FormEducation tempFormEducation = formEducation.ShallowCopy();
				wnFormEducation.DataContext = tempFormEducation;
            if (wnFormEducation.ShowDialog() == true)
                {
                    // сохранение данных
                    formEducation.NameForm = tempFormEducation.NameForm;
                    lvFormEducation.ItemsSource = null;
                    lvFormEducation.ItemsSource = vmFormEducation.ListFormEducation;
                }
            }
            else
            {
                MessageBox.Show("Необходимо выбрать форму обучения для редактированния",
                "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            FormEducationViewModel vmFormEducation = new FormEducationViewModel();
			FormEducation formEducation = (FormEducation)lvFormEducation.SelectedItem;
            if (formEducation != null)
            {
                MessageBoxResult result = MessageBox.Show("Удалить данные по форме обучения: " +
				formEducation.NameForm, "Предупреждение", MessageBoxButton.OKCancel,
                MessageBoxImage.Warning);
                if (result == MessageBoxResult.OK)
                {
					vmFormEducation.ListFormEducation.Remove(formEducation);
                }
            }
            else
            {
                MessageBox.Show("Необходимо выбрать форму обучения для удаления",
                "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
    }
}
