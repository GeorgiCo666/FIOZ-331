﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfApp1.Model;
using WpfApp1.ViewModel;

namespace WpfApp1.View
{
    /// <summary>
    /// Логика взаимодействия для WindowSpeciality.xaml
    /// </summary>
    public partial class WindowSpeciality : Window
    {
        SpecialityViewModel vmSpeciality = new SpecialityViewModel();
        public WindowSpeciality()
        {
            InitializeComponent();
            vmSpeciality = new SpecialityViewModel();
			lvSpeciality.ItemsSource = vmSpeciality.ListSpeciality;
        }
        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            SpecialityViewModel vmTypeAccount = new SpecialityViewModel();
			WindowNewSpeciality wnTypeAccount = new WindowNewSpeciality
			{
                Title = "Редактирование данных о специальностях",
                Owner = this
            };
            Speciality typeAccount = lvSpeciality.SelectedItem as Speciality;
            if (typeAccount != null)
            {
                Speciality tempTypeAccount = typeAccount.ShallowCopy();
                wnTypeAccount.DataContext = tempTypeAccount;
                if (wnTypeAccount.ShowDialog() == true)
                {
                    // сохранение данных
                    typeAccount.NameSpeciality = tempTypeAccount.NameSpeciality;
                    typeAccount.Profile = tempTypeAccount.Profile;
					lvSpeciality.ItemsSource = null;
					lvSpeciality.ItemsSource = vmSpeciality.ListSpeciality;
                }
            }
            else
            {
                MessageBox.Show("Необходимо выбрать специальность для редактированния",
                "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            SpecialityViewModel vmTypeAccount = new SpecialityViewModel();
            Speciality typeAccount = (Speciality)lvSpeciality.SelectedItem;
            if (typeAccount != null)
            {
                MessageBoxResult result = MessageBox.Show("Удалить специальность: " +
                typeAccount.NameSpeciality, "Предупреждение", MessageBoxButton.OKCancel,
                MessageBoxImage.Warning);
                if (result == MessageBoxResult.OK)
                {
                    vmTypeAccount.ListSpeciality.Remove(typeAccount);
                }
            }
            else
            {
                MessageBox.Show("Необходимо выбрать специальность для удаления",
                "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            WindowSpeciality wnTypeAccount = new WindowSpeciality
			{
                Title = "Новая специальность",
                Owner = this
            };
            // формирование кода новой специальности
            int maxIdTypeAccount = vmSpeciality.MaxId() + 1;
            Speciality typeAccount = new Speciality
            {
                Id = maxIdTypeAccount
            };
            wnTypeAccount.DataContext = typeAccount;
            if (wnTypeAccount.ShowDialog() == true)
            {
                vmSpeciality.ListSpeciality.Add(typeAccount);
            }
        }
    }

}
