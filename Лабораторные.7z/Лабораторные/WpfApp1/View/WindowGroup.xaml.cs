﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfApp1.Helper;
using WpfApp1.Model;
using WpfApp1.ViewModel;

namespace WpfApp1.View
{
    /// <summary>
    /// Логика взаимодействия для WindowGroup.xaml
    /// </summary>
    public partial class WindowGroup : Window
    {
        private GroupViewModel vmGroup = MainWindow.vmGroup;
        private FormEducationViewModel vmFormEducation;
        private SpecialityViewModel vmSpeciality;
        private QualificationViewModel vmQualification;
        private ObservableCollection<GroupDPO> groupsDPO;
        private List<FormEducation> forms;
        private List<Qualification> qualifications;
        private List<Speciality> specialities;

        public WindowGroup()
        {
            InitializeComponent();
			vmGroup = new GroupViewModel();
			vmFormEducation = new FormEducationViewModel();
			vmQualification = new QualificationViewModel();
			vmSpeciality = new SpecialityViewModel();
			forms = vmFormEducation.ListFormEducation.ToList();
			qualifications = vmQualification.ListQualification.ToList();
			specialities = vmSpeciality.ListSpeciality.ToList();
			groupsDPO = new ObservableCollection<GroupDPO>();
            foreach (var group in vmGroup.ListGroup)
            {
                GroupDPO g = new GroupDPO();
                g = g.CopyFromAccount(group);
				groupsDPO.Add(g);
            }
            lvGroup.ItemsSource = groupsDPO;
        }


        private void btn_Click(object sender, RoutedEventArgs e)
        {
            
        }

            private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            WindowNewGroup wnGroup = new WindowNewGroup()
            {
                Title = "Редактирование данных о группах",
                Owner = this
            };

            GroupDPO grDPO = (GroupDPO)lvGroup.SelectedValue;
            GroupDPO tempGrDPO;
            if (grDPO != null)
            {
				tempGrDPO = grDPO.ShallowCopy();
				wnGroup.DataContext = tempGrDPO;
				wnGroup.CbFormEducation.ItemsSource = forms;
				wnGroup.CbFormEducation.Text = tempGrDPO.FormEducation;
                wnGroup.CbQualification.ItemsSource = qualifications;
                wnGroup.CbQualification.Text = tempGrDPO.Qualification;
                wnGroup.CbSpeciality.ItemsSource = specialities;
                wnGroup.CbSpeciality.Text = tempGrDPO.Speciality;
                if (wnGroup.ShowDialog() == true)
                {
                    // перенос данных из временного класса в класс отображения данных 
                    Speciality s = (Speciality)wnGroup.CbSpeciality.SelectedValue;
                    Qualification q = (Qualification)wnGroup.CbQualification.SelectedValue;
                    FormEducation fe = (FormEducation)wnGroup.CbFormEducation.SelectedValue;
                    grDPO.Speciality = s.NameSpeciality;
                    grDPO.Course = tempGrDPO.Course;
                    grDPO.FormEducation = fe.NameForm;
                    grDPO.Faculty = tempGrDPO.Faculty;
                    grDPO.Name = tempGrDPO.Name;
                    grDPO.CountSubGroup = tempGrDPO.CountSubGroup;
                    grDPO.CountStudent = tempGrDPO.CountStudent;
                    lvGroup.ItemsSource = null;
                    lvGroup.ItemsSource = groupsDPO;

                    // перенос данных из класса отображения данных в класс Group
                    FindGroup finder = new FindGroup(grDPO.Id);
                    List<Group> listGroup = vmGroup.ListGroup.ToList();
                    Group g = listGroup.Find(new Predicate<Group>(finder.GroupPredicate));
                    g = g.CopyFromGroupDPO(grDPO);
                }
            }
            else
            {
                MessageBox.Show("Необходимо выбрать группу для редактированния",
                "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
            private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            WindowNewGroup wnGroup = new WindowNewGroup
            {
                Title = "Новая группа",
                Owner = this
            };
            // формирование кода новой группы
            int maxIdGroup = vmGroup.MaxId() + 1;
            GroupDPO gr = new GroupDPO
            {
                Id = maxIdGroup,
            };
			wnGroup.DataContext = gr;
			wnGroup.CbQualification.ItemsSource = qualifications;
            wnGroup.CbFormEducation.ItemsSource = forms;
            wnGroup.CbSpeciality.ItemsSource = specialities;

            
            if (wnGroup.ShowDialog() == true)
            {
                FormEducation f = (FormEducation)wnGroup.CbFormEducation.SelectedValue;
                Qualification q = (Qualification)wnGroup.CbQualification.SelectedValue;
                Speciality s = (Speciality)wnGroup.CbSpeciality.SelectedValue;

                gr.Speciality = s.NameSpeciality;
                gr.Qualification = q.NameQualification;
                gr.FormEducation = f.NameForm;
                groupsDPO.Add(gr);

                // добавление нового сотрудника в коллекцию ListGroup<Group> 
                Group g = new Group();
                g = g.CopyFromGroupDPO(gr);
                vmGroup.ListGroup.Add(g);
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            GroupViewModel vmGroup = new GroupViewModel();
            GroupDPO group = (GroupDPO)lvGroup.SelectedItem;
            if (group != null)
            {
                MessageBoxResult result = MessageBox.Show("Удалить данные по группе: " +
				group.Name, "Предупреждение", MessageBoxButton.OKCancel,
                MessageBoxImage.Warning);
                if (result == MessageBoxResult.OK)
                {
                    groupsDPO.Remove(group);
                    Group gr = new Group();
                    gr = gr.CopyFromGroupDPO(group);
                    vmGroup.ListGroup.Remove(gr);
                }
            }
            else
            {
                MessageBox.Show("Необходимо выбрать группу для удаления",
                "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
    }
}
