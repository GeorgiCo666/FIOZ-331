﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfApp1.Model;
using WpfApp1.ViewModel;

namespace WpfApp1.View
{
    /// <summary>
    /// Логика взаимодействия для WindowQualification.xaml
    /// </summary>
    public partial class WindowQualification : Window
    {
        QualificationViewModel vmQualification = new QualificationViewModel();
        public WindowQualification()
        {
            InitializeComponent();
			vmQualification = new QualificationViewModel();
			lvQualification.ItemsSource = vmQualification.ListQualification;
        }
        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            QualificationViewModel vmQualification = new QualificationViewModel();
			WindowNewQualification wnQualification = new WindowNewQualification
			{
                Title = "Редактирование данных о квалификациях",
                Owner = this
            };
            Qualification qualification = lvQualification.SelectedItem as Qualification;
            if (qualification != null)
            {
                Qualification tempQualification = qualification.ShallowCopy();
				wnQualification.DataContext = tempQualification;
                if (wnQualification.ShowDialog() == true)
                {
					// сохранение данных
					qualification.NameQualification = tempQualification.NameQualification;
					lvQualification.ItemsSource = null;
					lvQualification.ItemsSource = vmQualification.ListQualification;
                }
            }
            else
            {
                MessageBox.Show("Необходимо выбрать квалификацию для редактированния",
                "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            QualificationViewModel vmQualification = new QualificationViewModel();
            Qualification qualification = (Qualification)lvQualification.SelectedItem;
            if (qualification != null)
            {
                MessageBoxResult result = MessageBox.Show("Удалить данные по квалификации: " +
				qualification.NameQualification, "Предупреждение", MessageBoxButton.OKCancel,
                MessageBoxImage.Warning);
                if (result == MessageBoxResult.OK)
                {
					vmQualification.ListQualification.Remove(qualification);
                }
            }
            else
            {
                MessageBox.Show("Необходимо выбрать квалификацию для удаления",
                "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
			WindowNewQualification wnQualification = new WindowNewQualification
			{
                Title = "Новая квалификация",
                Owner = this
            };
            // формирование кода новой квалификации
            int maxIdQualification = vmQualification.MaxId() + 1;
            Qualification qualification = new Qualification
            {
                Id = maxIdQualification
			};
			wnQualification.DataContext = qualification;
            if (wnQualification.ShowDialog() == true)
            {
				vmQualification.ListQualification.Add(qualification);
            }
        }
        }
    }
